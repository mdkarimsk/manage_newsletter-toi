<?php
	session_start();
	//developed by Md Karim Sk

	$username=$pass = $wrngpss=$statement=$result=$pass="";
	$servername=$user_name=$password=$dbname=$data =$date=$stmt=$conn="";
	$servername = "localhost";
	$user_name = "root";
	$password = "";
	$dbname = "test";
	$conn = mysqli_connect($servername, $user_name, $password, $dbname);

	if ($conn->connect_error) {
  		die("Connection failed: " . $conn->connect_error);
	}

	function test_input($data) {
  		$data = trim($data);
  		$data = stripslashes($data);
  		$data = htmlspecialchars($data);
  		return $data;
	}

	if(isset($_POST['submit'])){

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
  			$username = test_input( $_POST["username"]);
  			$pass =test_input($_POST["password"]);
  			
	}

	$statement = $conn->prepare("SELECT * FROM admin WHERE username= ? LIMIT 1");
	$statement->bind_param("s",$username);
	$statement->execute();
	$result = $statement->get_result();

	if(mysqli_num_rows($result) > 0){

		$row_data=$result->fetch_assoc();
		if ($row_data['password'] == $pass) {
				
				$_SESSION['name']=$row_data['name'];
				header('Location: manage_newsletters-toi.php');
				die();
			}	

		else{

			$wrngpss="username/password is not valid..!";
		}
	}

	else{

		$wrngpss="username/password is not valid..!";

	}


}
//developed by Md Karim sk

?>



<!DOCTYPE html>
<html>
<head>
	<script>
		window.history.forward();
	</script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
	<title>Mange newslettes</title>
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css2?family=Kufam&display=swap');
		body{
			margin: 0;
			padding: 0;
			background-color: #605ca8;
			font-family: 'Kufam', cursive;
		}

		#top_msg{
			font-size: 20px;
			color: white;
		}

		#back_h{
			margin: 20px;
			text-decoration: none;
			font-size: 20px;
			color: white;
		}

		#back_h:hover{
			color: orange;
		}

		.admin_login{
			position: absolute;
			margin: 0px 32.5%;
			padding: 20px 0px;
			height: auto;
			width: 35%;
			background-color: white;
			text-align: center;
			border-radius: 5px;
			box-shadow: 5px grey;

		}

		.admin_login_form{
		
		}

		.admin_login_form input{
			width: 70%;
			height: 40px;
			margin-bottom: 35px;
			padding: 0px 15px;
			font-size: 17px;
			outline: none;
			border:none;
			background: transparent;
		}

		#in_f{
			border:0.5px solid #777E79 ;
			border-radius: 60px;
			background-color: rgba(21, 209, 93  ,0.1);
		}

		#lgn_btn{
			margin-bottom: 80px;
			background-color: #06A241;
			font-size: 20px;
			font-weight: bold;
			color: white;
			border-radius: 20px;
			cursor: pointer;

		}

	</style>
</head>
<body>
	<div>
		<span id="top_msg"><img src="TOI_logo.gif" width="300" height="80"></span>
		<a href="#" id="back_h" style="float: right;">&#xab; Back To Home Page</a>
	</div>
	<div class="admin_login">
		<img src="icon_toi.png" width="100" height="100">
		<h2>THINK OF IT FOUNDATION</h2>
		<h3>Admin Login</h3>
		<div class="admin_login_form">
			<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
				<input type="text" name="username" required="true" placeholder="enter username" id="in_f"><br>
				<input type="password" name="password" required="true" placeholder="enter password" id="in_f"><br>
				<input type="submit" name="submit" value="Login" id="lgn_btn">
				<span style="color: red;font-size: 17px;"><?php echo $wrngpss ; ?></span>
			</form>
		</div>
	</div>
	<div style="position: absolute;width: 100%;  bottom: 0;text-align: center;">
		<a href="https://karimsk.xyz/" style="text-decoration: none;color: white;font-size: 17px;">Developed by Md Karim Sk</a>
	</div>
</body>
</html>