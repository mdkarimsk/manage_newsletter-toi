<?php
session_start();
	$email_s=$emai_suc=$email_fail="";
	$servername = "localhost";
	$user_name = "root";
	$password = "";
	$dbname = "test";
	$conn = mysqli_connect($servername, $user_name, $password, $dbname);

	if ($conn->connect_error) {
  		die("Connection failed: " . $conn->connect_error);
	}

	function test_input($data) {
  		$data = trim($data);
  		$data = stripslashes($data);
  		$data = htmlspecialchars($data);
  		return $data;
	}

	if(isset($_POST['submit'])){

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
  			$to_email = test_input( $_POST["to_email"]);
  			$from_email =test_input($_POST["from_email"]);
  			$email_sub = test_input( $_POST["email_sub"]);
  			$email_body=test_input($_POST["email_content"]);
  			
	}

		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: THINK OF IT FOUNDATION '.'<'.$from_email.'>';

	if($to_email == "All Subscriber"){
		$sql = mysqli_query($conn, "SELECT * FROM subscriber_email");
	

   	while($row_3 = mysqli_fetch_array($sql)) {
   					$email_arr[] = $row_3['email'];
			}

			$email_s= implode(', ',$email_arr);

			if (mail($email_s, $email_sub, $email_body,$headers)) {
				
				$emai_suc="Email Sent Successfully";
			}

			else{
				$email_fail="Faile To Send Email..!";
			}

			

	}

	else{

		$email_s=test_input( $_POST["otherInput"]);

		if (mail($email_s, $email_sub, $email_body,$headers)) {
				
				$emai_suc="Email Sent Successfully";
			}

			else{
				$email_fail="Faile To Send Email..!";
			}

	}

}


if (isset($_GET['logout'])) {
	
	session_destroy();
	header('Location:newsletter_admin.php');
	exit();
}


if(isset($_POST['add_template'])){

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
  			$template_1 =test_input($_POST["template_name"]);
  			$email_body_1=test_input($_POST["email_content_1"]);
  			
	}


		$stmt1 = $conn->prepare("INSERT INTO email_template (template_name, email_body)  VALUES (?, ?)");
		$stmt1->bind_param("ss", $template_1, $email_body_1);
		$stmt1->execute();
		$stmt1->close();

}		

?>
<?php
	
	if(!isset($_SESSION['name'])) {
		header('Location:newsletter_admin.php');
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head>
	<script src="//cdn.ckeditor.com/4.15.0/full/ckeditor.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
	<title>Manage Newsletter</title>
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css2?family=Kufam&display=swap');
		body{
			margin: 0;
			padding: 0;
			background-color: #605ca8;
			font-family: 'Kufam', cursive;
			color: black;
		}

		.row{
			position: absolute;
			top: 65px;
			width:100%;
		}

		.column {
		  	float: left; 
		}
		
		.left {
		 	width: 19.75%;
		 	height: 100vh;
		 	border-right: 1px solid blue;

		}
		
		.right {
		  	width: 80%;
		  	height: auto;
		}
		
		.row:after {
		  content: "";
		  display: table;
		  clear: both;
		}

		.tab {
  			overflow: hidden;
		}

/* Style the buttons inside the tab */
.tab button {
	float: left;
	padding-left: 15px;
 	border: none;
 	outline: none;
 	cursor: pointer;
 	color: white;
 	transition: 0.3s;
 	font-size: 17px;
 	background: transparent;
}

/* Change background color of buttons on hover */
.tab button:hover {
  color: orange;
}

/* Create an active/current tablink class */
.tab button.active {
  color: orange;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}


.dropbtn {
  background-color: #3498DB;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  outline: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #2980B9;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #043FF7;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  border-bottom: 1px solid rgba(40,40,40,1);
}

.dropdown a:hover {color: orange;}

.show {display: block;}

input[type='text']{
	height: 20px;
	width: 40%;
	outline: none;
	color: black;
}

select{
	height: 20px;
	width: 40%;
	outline: none;
	color: black;
	font-size: 17px;
}


#sub-btn{
	padding: 10px 15px;
	outline: none;
	background-color: #3498DB;
	font-size: 20px;
	font-weight: bold;
	color: white;
	cursor: pointer;
}

#sel_btn{
	float: right;
	margin: 0px 15px;
	padding: 0px 15px;
	text-decoration: none;
	font-size: 17px;
	font-weight: bold;
	color:#0430F7 ;
}

#sel_btn:hover{
	color: #5D04F7 ;
}

@media screen and (max-width: 920px){
	
 	.left,.right{
 		width: 100%;
 	}

 	.left{
 		height: auto;
 	}

	}
		
	</style>
</head>
<body>
	<div style="">
		<p style="color: green;font-size: 20px;"><?php echo $emai_suc ; ?></p>
		<p style="color: red;font-size: 20px;"><?php echo $email_fail ; ?></p>
	</div>

	<div style="position: fixed;top: 0;width: 100%; height: 25px;padding: 20px 0px; background-color:rgba(75,75,75,1);z-index: 2;">
		<span style="float: right;font-size: 18px;color: white;padding-right:20px; ">
			<a href="manage_newsletters-toi.php?logout=yes" style="color: white;text-decoration: none;">Logout</a>
		</span>
		<span style="float: left;font-size: 18px;color: white;padding-left: 20px"><?php echo $_SESSION['name']; ?>&nbsp</span>
	</div>
	<div class="row">
 		<div class="column left">
 		  <div class="tab">
 				<br><button class="tablinks" onclick="openTab(event, 'send_mail')" id="defaultOpen">&#x2059; Send Emails &#xbb;</button>
 				<br><br>
 				<button class="tablinks" onclick="openTab(event, 'manage_email')">&#x2059; Manage Emails &#xbb;</button><br><br>
 				<button class="tablinks" onclick="openTab(event, 'template')">&#x2059; Manage Email Templates &#xbb;</button>
		</div>
 		</div>
 		<div class="column right" style="background-color:#bbb;">
 		  <div id="send_mail" class="tabcontent">
 		  	<div>
				<p style="color: green;font-size: 20px;"><?php echo $emai_suc ; ?></p>
				<p style="color: red;font-size: 20px;"><?php echo $email_fail ; ?></p>
			</div>
 			<div>
 				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
 					<div style="padding: 15px 10px;"> 
 					<div class="dropdown">
  							<button onclick="myFunction()" class="dropbtn">Select email Template &#xbb;</button>
  								<div id="myDropdown" class="dropdown-content">	
<?php 

 		$stat ="SELECT * FROM email_template";
		$query_2=$conn->query($stat);
		if(mysqli_num_rows($query_2) > 0){
			while($row_1=$query_2->fetch_assoc()){?>
			
						
    								<a href="manage_newsletters-toi.php?tem=<?php echo $row_1['template_name'] ;?>">
    									<?php echo $row_1['template_name'] ;?>&nbsp &nbsp &nbsp &#xbb;
    								</a>
 		
  												
  										

<?php
	}}

 ?>			
 		 						</div>
						</div>		
 					</div><?php

 						if (isset($_GET['tem'])) {?>

 							<div style="padding: 15px 10px;">
 								Selected Email Template : <span><?php echo$_GET['tem'] ;  ?></span>
 							</div>
 							
 					<?php	
 						}
 					 ?>
 					<div style="padding: 15px 10px;">
 						Send Emails To : <select onchange="checkOptions(this)" id="email" name="to_email">
 											<option value="" selected disabled hidden>Select</option>
  											<option value="All Subscriber">All Subscriber</option>
  											<option value="Custom">Custom</option>
										</select>
										<div id="cust_mail" style="display: none;padding: 20px;">
											Enter Emails : <input name='otherInput' id='otherInput' type="text" style="display: none" />
										</div>	
 					</div>
 					<div style="padding: 15px 10px;">
 						Send Emails From : <select id="emails" name="from_email">
 											<option value="" selected disabled hidden>Select</option>
  											<option value="hello@thinkofit.org">hello@thinkofit.org</option>
  											<option value="apply@thinkofit.org">apply@thinkofit.org</option>
  											<option value="donation@thinkofit.org">donation@thinkofit.org</option>
  											<option value="ceo@thinkofit.org">ceo@thinkofit.org</option>
										</select>
 					</div>
 					<div style="padding: 15px 10px;">
 						Email Temaplate Subject : <input type="text" name="email_sub" required="true">
 					</div>
 					<div style="padding: 15px 10px;">
 						Content of Email Template 
 						<textarea name="email_content" id="email_content" style="text-align: center;" required="true">
 						<div style="text-align: center;">	
 						<?php if (isset($_GET['tem'])) {
 							$st = $conn->prepare("SELECT * FROM email_template WHERE template_name= ? LIMIT 1");
							$st->bind_param("s",$_GET['tem']);
							$st->execute();
							$res = $st->get_result();

							if(mysqli_num_rows($res) > 0){

								$row=$res->fetch_assoc();?>
								
									<?php echo $row['email_body'];?>
							<?php
							}
 						} ?> 
 							</div>
 						</textarea> 
 				</div>
 					<div style="padding: 15px 10px;">
 						 <input type="submit" name="submit" value="Send" id="sub-btn">
 					</div>
 				</form>
 			</div>

		  </div>

		<div id="manage_email" class="tabcontent">
			<h2>&#x203B; Subscriber Emails</h2> 
			<?php 

 		$statement ="SELECT * FROM subscriber_email";
		$query=$conn->query($statement);
		if(mysqli_num_rows($query) > 0){
			while($row=$query->fetch_assoc()){?>
			
										
  												<p><?php echo $row['id'].". ".$row['email'] ;?></p>
  										

<?php
	}}

 ?>
		</div>

		<div id="template" class="tabcontent">
 				<div><h2>&#x203B; Email Templates</h2>
 <?php 

 		$state ="SELECT * FROM email_template";
		$query_1=$conn->query($state);
		if(mysqli_num_rows($query) > 0){
			while($row=$query_1->fetch_assoc()){?>
			<p style="border-bottom: 1px solid black;padding: 10px 0px;color: black;font-size: 17px;">&#xbb;&nbsp<?php echo $row['template_name'] ;?>&nbsp &nbsp &nbsp
			<a href="manage_newsletters-toi.php?tem=<?php echo $row['template_name'] ;?>" id="sel_btn"> SELECT</a>
			</p>
		

<?php
	}}

 ?>
 			</div>
 		<div>
 			<h2>&#x203B; Create Email Templates</h2>
 			<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">	
 				<div style="padding: 20px 0px;">	
 					Template Name : <input type="text" name="template_name" required="true">
 				</div>
 				<div style="padding: 20px 0px;">	
 					<textarea name="email_content_1" id="email_content_1" style="text-align: center;" required="true"></textarea>
 				</div>
 				<div style="padding: 20px 0px;">	
 					<input type="submit" name="add_template" value="Save Template" id="sub-btn">
 				</div>	
 			</form>
 		</div>	
		</div>
 		</div>
	</div>
	<script type="text/javascript">
		function openTab(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

document.getElementById("defaultOpen").click();


function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}





var otherInput,cust;
function checkOptions(select) {
 cust = document.getElementById('cust_mail');		
  otherInput = document.getElementById('otherInput');
  if (select.options[select.selectedIndex].value == "Custom") {
    otherInput.style.display = 'block';
    cust.style.display = 'block';
    
  }
  else {
    otherInput.style.display = 'none';
    cust.style.display = 'none';
  }
}


CKEDITOR.replace( 'email_content', {
  height: 300,
  filebrowserUploadUrl: "upload.php",
  filebrowserUploadMethod: "form"
 });


CKEDITOR.replace( 'email_content_1', {
  height: 300,
  filebrowserUploadUrl: "upload.php",
  filebrowserUploadMethod: "form"
 });

//developed by Md Karim sk

	</script>
</body>
</html>

