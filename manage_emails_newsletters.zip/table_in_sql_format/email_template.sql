-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2020 at 01:04 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `email_template`
--

CREATE TABLE `email_template` (
  `id` int(10) NOT NULL,
  `template_name` varchar(100) NOT NULL,
  `email_body` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_template`
--

INSERT INTO `email_template` (`id`, `template_name`, `email_body`) VALUES
(13, 'Test-email-template', '&lt;p style=&quot;text-align:center&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;upload/1405666614.png&quot; style=&quot;height:42px; width:200px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Dear Mr. Md Karim S K,&lt;br /&gt;\r\nCongratulations on being selected for this internship-volunteering&lt;br /&gt;\r\nexperience.&lt;br /&gt;\r\n&lt;br /&gt;\r\nIt is with great pleasure that we would like to offer you the position&lt;br /&gt;\r\nof Backend Developer intern at THINK OF IT FOUNDATION.&lt;br /&gt;\r\nThe whole team extends their congratulations and looks forward to&lt;br /&gt;\r\nwelcoming you on-board.&lt;br /&gt;\r\n&lt;br /&gt;\r\nThis offer is valid only on signing/agreeing to the offer document&lt;br /&gt;\r\nattached below.&lt;br /&gt;\r\n&lt;br /&gt;\r\nTo accept this offer, reply to this mail in the following format :&lt;br /&gt;\r\nI, your_name, accept the offer and shall abide by the agreement&lt;br /&gt;\r\nmentioned.&lt;br /&gt;\r\n&lt;br /&gt;\r\nKindly send the signed offer letter within 48 hours.&lt;br /&gt;\r\n&lt;br /&gt;\r\nFeel free to think outside the box and surprise us with your passion.&lt;br /&gt;\r\n&lt;br /&gt;\r\n&amp;quot;No matter what they tell you, words and ideas can change the world.&amp;quot;&lt;br /&gt;\r\n&lt;br /&gt;\r\nRegards,&lt;br /&gt;\r\nRiya Elizabeth Mathew&lt;br /&gt;\r\nHuman Resource, TOI&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;a href=&quot;https://www.thinkofit.org/&quot; target=&quot;_blank&quot;&gt;THINK OF IT FOUNDATION&lt;/a&gt;&lt;/p&gt;\r\n\r\n&lt;p style=&quot;text-align:center&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;upload/2030300451.png&quot; style=&quot;height:64px; width:64px&quot; /&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;upload/1570723804.png&quot; style=&quot;height:64px; width:64px&quot; /&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;upload/1431786403.png&quot; style=&quot;height:64px; width:64px&quot; /&gt;&lt;/p&gt;');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email_template`
--
ALTER TABLE `email_template`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email_template`
--
ALTER TABLE `email_template`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
